"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.transformSizes = void 0;
exports.transformSizes = [
    {
        width: 32,
        height: 32
    },
    {
        width: 64,
        height: 64
    },
    {
        width: 128,
        height: 128
    }
];
//# sourceMappingURL=constants.js.map